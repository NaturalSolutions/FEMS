<?php

	/* Include all individual CPT. */
	$prefix_cpt = "cpt_";

	/* Clients */
	require_once( $prefix_cpt . "clients.php" );

	/* Gallery */
	require_once( $prefix_cpt . "gallery.php" );
?>